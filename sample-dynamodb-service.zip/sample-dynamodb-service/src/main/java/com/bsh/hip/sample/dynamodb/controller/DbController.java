package com.bsh.hip.sample.dynamodb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bsh.hip.sample.dynamodb.model.SampleUser;
import com.bsh.hip.sample.dynamodb.repository.DynamoDbRepository;

@RestController
@RequestMapping(path = "/db")
public class DbController {

	@Autowired
	private DynamoDbRepository repo;

	@PostMapping("/users/insert")
	public String insertintoDb(SampleUser user) {
		repo.insertIntoDynamoDB(user);
		return "Successfully inserted";

	}

	@GetMapping("/users/retreive")
	public SampleUser insertintoDb(@RequestHeader String  userId, @RequestHeader String lastName) {
		SampleUser user = repo.getOneUserDetail(userId,lastName);
		return user;

	}

	@GetMapping("users")
	public SampleUser returnjson() {
		SampleUser user = new SampleUser();
//		user.setFirstName("Subash");
		user.setLastName("Muthumanickam");
//		user.setOrganization("BSH");
//		user.setRole("Developer");
		user.setUserId("1122");
		return user;
	}
}
