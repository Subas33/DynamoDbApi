package com.bsh.hip.sample.dynamodb.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.bsh.hip.sample.dynamodb.model.SampleUser;

@Repository
public class DynamoDbRepository {

	@Autowired
	private DynamoDBMapper mapper;

	public void insertIntoDynamoDB(SampleUser user) {
		mapper.save(user);
	}

	public SampleUser getOneUserDetail(String userId, String lastName) {
		return mapper.load(SampleUser.class, userId, lastName);
	}
}
